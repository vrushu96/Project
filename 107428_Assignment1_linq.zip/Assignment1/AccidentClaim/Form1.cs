﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AccidentClaim
{

    public partial class Form1 : Form
    {
        //DataClasses1DataContext ctx = new DataClasses1DataContext();
        OperationsDataContext odx = new OperationsDataContext();
        public Form1()
        {
            InitializeComponent();
        }



        private void btn_Add_Click(object sender, EventArgs e)
        {
            //txt_claimNo.Enabled = true;
            //txt_claimNo.Visible = false;
            AccidentClaimTable ac = new AccidentClaimTable();
            ac.PolicyNo = Convert.ToInt32(txt_policyNo.Text);
            ac.VehicleNo = txt_vehicleNo.Text;
            ac.OwnerName = txt_owner.Text;
            ac.AccidentLoc = txt_AccLoc.Text;
            ac.PolicyRegisLoc = txt_polReg.Text;
            ac.MembersInjured = Convert.ToInt32(txt_memberInjured.Text);

            odx.AccidentClaimTables.InsertOnSubmit(ac);
            odx.SubmitChanges();
            MessageBox.Show("Inserted Successfully");

        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            AccidentClaimTable ac = new AccidentClaimTable();
            var res = odx.AccidentClaimTables.Where(x => x.ClaimNo == Convert.ToInt32(txt_claimNo.Text)).First();



            if (res != null)
            {
                res.PolicyNo = int.Parse(txt_policyNo.Text);
                res.VehicleNo = txt_vehicleNo.Text;
                res.OwnerName = txt_owner.Text;
                res.AccidentLoc = txt_AccLoc.Text;
                res.PolicyRegisLoc = txt_polReg.Text;
                res.MembersInjured = int.Parse(txt_memberInjured.Text);

                odx.SubmitChanges();
                MessageBox.Show("Updated Successfully");

            }
            else
            {
                MessageBox.Show("Claim Number not found");
            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            btn_Add.Visible = false;
            btn_update.Visible = true;
            btn_delete.Visible = true;
            //txt_claimNo.Enabled = true;

            AccidentClaimTable ac = new AccidentClaimTable();
            var res = odx.AccidentClaimTables.Where(x => x.ClaimNo == Convert.ToInt32(txt_claimNo.Text)).First();



            if (res != null)
            {
                txt_policyNo.Text = Convert.ToInt32(res.PolicyNo).ToString();
                txt_vehicleNo.Text = res.VehicleNo.ToString(); ;
                txt_owner.Text = res.OwnerName.ToString();
                txt_AccLoc.Text = res.AccidentLoc.ToString();
                txt_polReg.Text = res.PolicyRegisLoc.ToString();
                txt_memberInjured.Text = Convert.ToInt32(res.MembersInjured).ToString();

                odx.SubmitChanges();

            }
            else
            {
                MessageBox.Show("Claim Number not found");
            }



        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            AccidentClaimTable ac = new AccidentClaimTable();
            // var res = odx.AccidentClaimTables.Where(x => x.ClaimNo == Convert.ToInt32(txt_claimNo.Text)).First();
            var res = odx.AccidentClaimTables.Where(x => x.ClaimNo == Convert.ToInt32(txt_claimNo.Text)).First();

            if (res != null)
            {
                odx.AccidentClaimTables.DeleteOnSubmit(res);
                odx.SubmitChanges();
                MessageBox.Show("Deleted Successfully");
            }
            else
            {
                MessageBox.Show("Claim Number not found");
            }
        }

        private void btn_savefile_Click(object sender, EventArgs e)
        {
            // var root=new XElement()
            var res = odx.AccidentClaimTables.ToList().Where(x => x.ClaimNo == Convert.ToInt32(txt_claimNo.Text));
            using (TextWriter txt = new StreamWriter("D:\\vrushali\\Linq\\AccidentClaim.txt"))
            //using (StreamWriter sw = File.AppendText("D:\\vrushali\\Linq\\AccidentClaim.txt"))
            {
                foreach (var item in res)
                {
                    txt.WriteLine(string.Format($"Claim Number: {item.ClaimNo}, \n Policy Number {item.PolicyNo}, \n Vehicle Number: {item.VehicleNo}, \n Owner Name: {item.OwnerName}, \n Accident Location: {item.AccidentLoc}, \n Policy Registration Location: {item.PolicyRegisLoc}, \n Members Injured: {item.MembersInjured}"));
                    //txt.WriteLine(string.Format("Policy Number {0}, Vehicle Number: {1}, Owner Name: {2}, Accident Location: {3}, Policy Registration Location: {4}, Members Injured: {5}"));

                }
            }
        }
    }
}
