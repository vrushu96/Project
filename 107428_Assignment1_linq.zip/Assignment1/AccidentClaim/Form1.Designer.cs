﻿namespace AccidentClaim
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_policyNo = new System.Windows.Forms.Label();
            this.txt_policyNo = new System.Windows.Forms.TextBox();
            this.lbl_vehicleNo = new System.Windows.Forms.Label();
            this.lbl_owner = new System.Windows.Forms.Label();
            this.lbl_accLoc = new System.Windows.Forms.Label();
            this.lbl_polReg = new System.Windows.Forms.Label();
            this.lbl_memberInjured = new System.Windows.Forms.Label();
            this.txt_vehicleNo = new System.Windows.Forms.TextBox();
            this.txt_owner = new System.Windows.Forms.TextBox();
            this.txt_AccLoc = new System.Windows.Forms.TextBox();
            this.txt_polReg = new System.Windows.Forms.TextBox();
            this.txt_memberInjured = new System.Windows.Forms.TextBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.txt_claimNo = new System.Windows.Forms.TextBox();
            this.lbl_claimNo = new System.Windows.Forms.Label();
            this.btn_savefile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_policyNo
            // 
            this.lbl_policyNo.AutoSize = true;
            this.lbl_policyNo.Location = new System.Drawing.Point(54, 39);
            this.lbl_policyNo.Name = "lbl_policyNo";
            this.lbl_policyNo.Size = new System.Drawing.Size(78, 13);
            this.lbl_policyNo.TabIndex = 0;
            this.lbl_policyNo.Text = "Policy Number ";
            // 
            // txt_policyNo
            // 
            this.txt_policyNo.Location = new System.Drawing.Point(259, 39);
            this.txt_policyNo.Name = "txt_policyNo";
            this.txt_policyNo.Size = new System.Drawing.Size(100, 20);
            this.txt_policyNo.TabIndex = 1;
            // 
            // lbl_vehicleNo
            // 
            this.lbl_vehicleNo.AutoSize = true;
            this.lbl_vehicleNo.Location = new System.Drawing.Point(54, 79);
            this.lbl_vehicleNo.Name = "lbl_vehicleNo";
            this.lbl_vehicleNo.Size = new System.Drawing.Size(85, 13);
            this.lbl_vehicleNo.TabIndex = 2;
            this.lbl_vehicleNo.Text = "Vehicle Number ";
            // 
            // lbl_owner
            // 
            this.lbl_owner.AutoSize = true;
            this.lbl_owner.Location = new System.Drawing.Point(54, 122);
            this.lbl_owner.Name = "lbl_owner";
            this.lbl_owner.Size = new System.Drawing.Size(69, 13);
            this.lbl_owner.TabIndex = 3;
            this.lbl_owner.Text = "Owner Name";
            // 
            // lbl_accLoc
            // 
            this.lbl_accLoc.AutoSize = true;
            this.lbl_accLoc.Location = new System.Drawing.Point(54, 166);
            this.lbl_accLoc.Name = "lbl_accLoc";
            this.lbl_accLoc.Size = new System.Drawing.Size(93, 13);
            this.lbl_accLoc.TabIndex = 4;
            this.lbl_accLoc.Text = "Accident Location";
            // 
            // lbl_polReg
            // 
            this.lbl_polReg.AutoSize = true;
            this.lbl_polReg.Location = new System.Drawing.Point(54, 212);
            this.lbl_polReg.Name = "lbl_polReg";
            this.lbl_polReg.Size = new System.Drawing.Size(138, 13);
            this.lbl_polReg.TabIndex = 5;
            this.lbl_polReg.Text = "Policy Registration Location";
            // 
            // lbl_memberInjured
            // 
            this.lbl_memberInjured.AutoSize = true;
            this.lbl_memberInjured.Location = new System.Drawing.Point(54, 253);
            this.lbl_memberInjured.Name = "lbl_memberInjured";
            this.lbl_memberInjured.Size = new System.Drawing.Size(85, 13);
            this.lbl_memberInjured.TabIndex = 6;
            this.lbl_memberInjured.Text = "Members Injured";
            // 
            // txt_vehicleNo
            // 
            this.txt_vehicleNo.Location = new System.Drawing.Point(259, 79);
            this.txt_vehicleNo.Name = "txt_vehicleNo";
            this.txt_vehicleNo.Size = new System.Drawing.Size(100, 20);
            this.txt_vehicleNo.TabIndex = 7;
            // 
            // txt_owner
            // 
            this.txt_owner.Location = new System.Drawing.Point(259, 115);
            this.txt_owner.Name = "txt_owner";
            this.txt_owner.Size = new System.Drawing.Size(100, 20);
            this.txt_owner.TabIndex = 8;
            // 
            // txt_AccLoc
            // 
            this.txt_AccLoc.Location = new System.Drawing.Point(259, 166);
            this.txt_AccLoc.Name = "txt_AccLoc";
            this.txt_AccLoc.Size = new System.Drawing.Size(100, 20);
            this.txt_AccLoc.TabIndex = 9;
            // 
            // txt_polReg
            // 
            this.txt_polReg.Location = new System.Drawing.Point(259, 212);
            this.txt_polReg.Name = "txt_polReg";
            this.txt_polReg.Size = new System.Drawing.Size(100, 20);
            this.txt_polReg.TabIndex = 10;
            // 
            // txt_memberInjured
            // 
            this.txt_memberInjured.Location = new System.Drawing.Point(259, 253);
            this.txt_memberInjured.Name = "txt_memberInjured";
            this.txt_memberInjured.Size = new System.Drawing.Size(100, 20);
            this.txt_memberInjured.TabIndex = 11;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(259, 312);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(75, 23);
            this.btn_Add.TabIndex = 12;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_search
            // 
            this.btn_search.Location = new System.Drawing.Point(390, 311);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(75, 23);
            this.btn_search.TabIndex = 13;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // btn_update
            // 
            this.btn_update.Location = new System.Drawing.Point(259, 361);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(75, 23);
            this.btn_update.TabIndex = 14;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Visible = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(390, 361);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 15;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Visible = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // txt_claimNo
            // 
            this.txt_claimNo.Location = new System.Drawing.Point(259, 4);
            this.txt_claimNo.Name = "txt_claimNo";
            this.txt_claimNo.Size = new System.Drawing.Size(100, 20);
            this.txt_claimNo.TabIndex = 16;
            // 
            // lbl_claimNo
            // 
            this.lbl_claimNo.AutoSize = true;
            this.lbl_claimNo.Location = new System.Drawing.Point(57, 4);
            this.lbl_claimNo.Name = "lbl_claimNo";
            this.lbl_claimNo.Size = new System.Drawing.Size(72, 13);
            this.lbl_claimNo.TabIndex = 17;
            this.lbl_claimNo.Text = "Claim Number";
            // 
            // btn_savefile
            // 
            this.btn_savefile.Location = new System.Drawing.Point(259, 412);
            this.btn_savefile.Name = "btn_savefile";
            this.btn_savefile.Size = new System.Drawing.Size(75, 23);
            this.btn_savefile.TabIndex = 18;
            this.btn_savefile.Text = "Save To Text File";
            this.btn_savefile.UseVisualStyleBackColor = true;
            this.btn_savefile.Click += new System.EventHandler(this.btn_savefile_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(677, 460);
            this.Controls.Add(this.btn_savefile);
            this.Controls.Add(this.lbl_claimNo);
            this.Controls.Add(this.txt_claimNo);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.txt_memberInjured);
            this.Controls.Add(this.txt_polReg);
            this.Controls.Add(this.txt_AccLoc);
            this.Controls.Add(this.txt_owner);
            this.Controls.Add(this.txt_vehicleNo);
            this.Controls.Add(this.lbl_memberInjured);
            this.Controls.Add(this.lbl_polReg);
            this.Controls.Add(this.lbl_accLoc);
            this.Controls.Add(this.lbl_owner);
            this.Controls.Add(this.lbl_vehicleNo);
            this.Controls.Add(this.txt_policyNo);
            this.Controls.Add(this.lbl_policyNo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_policyNo;
        private System.Windows.Forms.TextBox txt_policyNo;
        private System.Windows.Forms.Label lbl_vehicleNo;
        private System.Windows.Forms.Label lbl_owner;
        private System.Windows.Forms.Label lbl_accLoc;
        private System.Windows.Forms.Label lbl_polReg;
        private System.Windows.Forms.Label lbl_memberInjured;
        private System.Windows.Forms.TextBox txt_vehicleNo;
        private System.Windows.Forms.TextBox txt_owner;
        private System.Windows.Forms.TextBox txt_AccLoc;
        private System.Windows.Forms.TextBox txt_polReg;
        private System.Windows.Forms.TextBox txt_memberInjured;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.TextBox txt_claimNo;
        private System.Windows.Forms.Label lbl_claimNo;
        private System.Windows.Forms.Button btn_savefile;
    }
}

