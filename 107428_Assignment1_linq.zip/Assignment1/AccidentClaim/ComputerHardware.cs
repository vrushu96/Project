﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AccidentClaim
{
    class ComputerHardware
    {
        public string Name { get; set; }
        public int Code { get; set; }
        public double Price { get; set; }
        public int Warranty { get; set; }
        public string Manufacturer { get; set; }
        public double MrpPrice { get; set; }
        public DateTime WarrantyEndDate { get; set; }

        public ComputerHardware(string Name, int Code, double Price, int Warranty, string Manufacturer, double MrpPrice, DateTime WarrantyEndDate)
        {
            this.Name = Name;
            this.Code = Code;
            this.Price = Price;
            this.Warranty = Warranty;
            this.Manufacturer = Manufacturer;
            this.MrpPrice = MrpPrice;
            this.WarrantyEndDate = WarrantyEndDate;
        }

        List<ComputerHardware> productList = new List<ComputerHardware>()
        {
            new ComputerHardware("CPU", 101, 2300d, 3, "Samsung", 4000d, Convert.ToDateTime(27-10-2018)),
            new ComputerHardware("Monitor", 102, 1500d, 8, "HP", 3000d, Convert.ToDateTime(17-10-2019)),
            new ComputerHardware("Mouse", 103, 1000d, 6, "Samsung", 1200d, Convert.ToDateTime(27-05-2019)),
            new ComputerHardware("Keyboard", 104, 5000d, 3, "Apple", 5500d, Convert.ToDateTime(16-12-2018)),
            new ComputerHardware("Motherboard", 105, 10000d, 20, "HP", 11000d, Convert.ToDateTime(15-03-2019)),
            new ComputerHardware("CD-ROM", 106, 7000d, 3, "Lenovo", 7500d, Convert.ToDateTime(08-1-2019)),
            new ComputerHardware("RAM", 107, 12000d, 9, "Dell", 13000d, Convert.ToDateTime(2-08-2020)),
            new ComputerHardware("Floppy Drive", 108, 4500d, 2, "Lenovo", 4500d, Convert.ToDateTime(11-02-2019)),
            new ComputerHardware("Scanner", 109, 7000d, 15, "Canon", 7200d, Convert.ToDateTime(28-11-2020)),
            new ComputerHardware("Printer", 110, 15000d, 24, "Canon", 15600d, Convert.ToDateTime(10-12-2020)),
        };

        public void disp()
        {
            var query = (from products in productList
                         where products.Warranty > 15
                         orderby products descending
                         select products);

            foreach (var item in productList)
            {
                Console.WriteLine(item);
            }
        }
    }
}
