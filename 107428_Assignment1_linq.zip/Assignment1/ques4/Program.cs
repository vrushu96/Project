﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace ques4
{
    class Program
    {

        
        static void Main(string[] args)
        {
            XDocument xdoc = XDocument.Load("D:/Vrushali\\Linq\\Products.xml");

            
            var query = from q in xdoc.Descendants("ComputerHardware").Elements("Product")
                        where (int)q.Element("Price") > 1000 && (int)q.Element("Warranty") < 2
                        select q.Value;

            foreach (var item in query)
            {
                Console.WriteLine(item);
            }
        }
    }
}
