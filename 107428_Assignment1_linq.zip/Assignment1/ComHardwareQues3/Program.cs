﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace ComHardwareQues3
{
    class ComputerHardware
    {
        public string Name { get; set; }
        public int Code { get; set; }
        public double Price { get; set; }
        public int Warranty { get; set; }
        public string Manufacturer { get; set; }
        public double MrpPrice { get; set; }
        public DateTime WarrantyEndDate { get; set; }

       

       
    }
    class Program
    {
        List<ComputerHardware> productList = new List<ComputerHardware>()
        {
            new ComputerHardware{Name="CPU", Code=101, Price=2300d, Warranty=1, Manufacturer="Samsung", MrpPrice=4000d, WarrantyEndDate=Convert.ToDateTime("27-10-2018")},
            new ComputerHardware{Name="Monitor", Code=102, Price=1500d, Warranty=20, Manufacturer="HP", MrpPrice=3000d, WarrantyEndDate=Convert.ToDateTime("17-10-2019")},
            new ComputerHardware{Name="Mouse", Code=103, Price=1000d, Warranty=6, Manufacturer="Samsung", MrpPrice=1200d, WarrantyEndDate=Convert.ToDateTime("27-05-2019")},
            new ComputerHardware{Name="Keyboard", Code=102, Price=5000d, Warranty=3, Manufacturer="Apple", MrpPrice=5500d, WarrantyEndDate=Convert.ToDateTime("16-12-2018")},
            new ComputerHardware {Name="Motherboard", Code=105, Price=10000d, Warranty=20, Manufacturer="HP", MrpPrice=11000d, WarrantyEndDate=Convert.ToDateTime("15-03-2019")},
            new ComputerHardware{Name="CD-ROM", Code=106, Price=7000d, Warranty=3, Manufacturer="Lenovo", MrpPrice=7500d, WarrantyEndDate=Convert.ToDateTime("08-1-2019")},
            new ComputerHardware {Name="RAM", Code=107, Price=12000d, Warranty=9, Manufacturer="Dell", MrpPrice=13000d, WarrantyEndDate= Convert.ToDateTime("2-08-2020")},
            new ComputerHardware{Name="Floppy Drive", Code=108, Price=4500d, Warranty=1, Manufacturer="Lenovo", MrpPrice=4500d, WarrantyEndDate=Convert.ToDateTime("11-02-2019")},
            new ComputerHardware{Name="Scanner", Code=109, Price=7000d, Warranty=15, Manufacturer="Canon", MrpPrice=7200d, WarrantyEndDate=Convert.ToDateTime("28-11-2020")},
            new ComputerHardware{Name="Printer", Code=110, Price=15000d, Warranty=24, Manufacturer="Canon", MrpPrice=15600d, WarrantyEndDate=Convert.ToDateTime("10-12-2020")},
        };

        public void disp()
        {
            var query = (from products in productList.ToList()
                         where products.Warranty > 15
                         orderby products.Price descending
                         select products);

            foreach (var item in query)
            {
                Console.WriteLine($"\n Name: {item.Name}, COde:{item.Code}, Price:{item.Price}, Warranty: {item.Warranty}, Manufacturer: {item.Manufacturer}, MRP: {item.MrpPrice}, Warranty End Date:{item.WarrantyEndDate}");
            }
        }


        void createXml()
        {
            var root = new XElement("ComputerHardware",
                from p in productList
                select new XElement("Product",
                new XAttribute("Name", p.Name),
                new XElement("Code", p.Code),
                new XElement("Price", p.Price),
                new XElement("Warranty", p.Warranty),
                new XElement("Manufacturer", p.Manufacturer),
                new XElement("MRP", p.MrpPrice),
                new XElement("Warranty_EndDate", p.WarrantyEndDate)));

            root.Save("D:/Vrushali\\Linq\\Products.xml");
        }
        static void Main(string[] args)
        {

            Program ch= new Program();
            ch.disp();
            ch.createXml();
           // ch.ShowFromXMLDoc();

        }
    }
}
