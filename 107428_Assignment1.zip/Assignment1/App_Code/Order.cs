﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for Order
/// </summary>
public class Order
{
    public int OrderId { get; set; }
    public DateTime OrderDate { get; set; }
    public List<Item> OrderCart { get; set; }

    public Order()
    {
        OrderId = new Random().Next(1, 100);
        OrderDate = DateTime.Now.Date;
    }

    public void orderList(GridView gv)
    {
       // gv.DataSource = Order();
       // gv.DataBind();
    }
}