﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for MainClass
/// </summary>
public class MenuService
{
  

    public static Item[] itemList = new Item[]
      {
        new Item(1, "Dosa", 20, 15),
        new Item(2, "Maggi", 2, 20),
        new Item(3, "Pizza", 30, 100),
        new Item(4, "Biryani", 30, 100),
        new Item(5, "Pani Puri", 30, 100),
        new Item(6, "Chole", 30, 100),
        new Item(7, "Samosa", 30, 100),




      };


    public void PrintList(GridView gc)
    {
        gc.DataSource = itemList;
        gc.DataBind();
    }
}