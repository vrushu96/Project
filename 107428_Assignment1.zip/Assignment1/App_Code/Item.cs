﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Item
/// </summary>
public class Item
{
    public int ItemId { get; set; }
    public string ItemName { get; set; }
    public int ItemPrepTime { get; set; }
    public float ItemPrice { get; set; }

    public Item()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public Item(int ItemId, string ItemName, int ItemPrepTime, float ItemPrice)
    {
        this.ItemId = ItemId;
        this.ItemName = ItemName;
        this.ItemPrepTime = ItemPrepTime;
        this.ItemPrice = ItemPrice;
    }
}