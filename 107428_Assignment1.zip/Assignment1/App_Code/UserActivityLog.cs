﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UserActivityLog
/// </summary>
public class UserActivityLog
{
    public UserActivityLog()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public class Main
    {
        private SqlConnection conn;
        public static SqlConnection GetConnection()
        {
            SqlConnection conn = new SqlConnection("Data Source=(local)\\SQLEXPRESS;Initial Catalog=ActivityLog; Integrated Security=true");
            return conn;
        }
    }
}