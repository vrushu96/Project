﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowMenu : System.Web.UI.Page
{

    SqlConnection conn;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["name"] == null)
        {
            Response.Redirect("Login.aspx?error=403&page=index.aspx");
        }

        MenuService ms = new MenuService();
        ms.PrintList(Grid1D);
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        if (!IsPostBack)
        {
            DbValues();
        }
    }

    private void DbValues()
    {
        using (SqlCommand cmd = new SqlCommand())
        {
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "select * from Restaurant";
            SqlDataReader dr = cmd.ExecuteReader();

            GridView2.DataSource = dr;
            GridView2.DataBind();
            conn.Close();
        }
    }
}


