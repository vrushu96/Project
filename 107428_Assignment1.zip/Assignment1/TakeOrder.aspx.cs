﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TakeOrder : System.Web.UI.Page
{
    double sum = 0;


    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["name"] == null)
        {
            Response.Redirect("Login.aspx?error=403&page=index.aspx");
        }
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        if (!IsPostBack)
        {
            loaditem();
        }
    }

    private void loaditem()
    {
        using (SqlCommand cmd = new SqlCommand())
        {
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "select ItemId, ItemName from Restaurant;";
            SqlDataReader dr = cmd.ExecuteReader();
            ddl_item.DataSource = dr;
            ddl_item.DataTextField = "ItemName";
            ddl_item.DataValueField = "ItemId";
            ddl_item.DataBind();
            ddl_item.Items.Insert(0, "select");
            conn.Close();

            //ddl_item.DataSource = MenuService.itemList;
            //ddl_item.DataTextField = "ItemName";
            //ddl_item.DataValueField = "ItemId";
            //ddl_item.DataBind();

        }


    }





    protected void btn_saveOrder_Click(object sender, EventArgs e)
    {

        if (Session["cart"] == null)
        {
            List<Item> cart = new List<Item>();
            using (SqlCommand cmd = new SqlCommand())
            {
                conn.Open();
                cmd.Connection = conn;
                cmd.CommandText = "select ItemName, ItemPrepTime, ItemPrice from Restaurant where ItemId=" + ddl_item.SelectedItem.Value;
                IDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    var menuList = new Item();
                    //menuList.ItemId = Convert.ToInt32(dr["ItemId"]);
                    menuList.ItemId = ddl_item.SelectedIndex;
                    menuList.ItemName = dr["ItemName"].ToString();
                    menuList.ItemPrepTime = Convert.ToInt32(dr["ItemPrepTime"].ToString());
                    menuList.ItemPrice = Convert.ToSingle(dr["ItemPrice"].ToString());

                    cart.Add(menuList);
                }
                Session["cart"] = cart;

                conn.Close();
                GridView_Order.DataSource = cart;
                GridView_Order.DataBind();


                // var item = MenuService.itemList.ToList().Find(x => x.ItemId == int.Parse(ddl_item.Text));
                //if (item != null)
                //{
                //    item.ItemId = 1;
                //    cart.Add(new Item { ItemId = 1, ItemName = item.ItemName, ItemPrepTime = item.ItemPrepTime, ItemPrice = item.ItemPrice * (Convert.ToInt32(txt_quant.Text))});
                //    Session["cart"] = cart;
                //}
            }

        }
        else
        {

            List<Item> cart = (List<Item>)Session["cart"];
            using (SqlCommand cmd = new SqlCommand())
            {
                conn.Open();
                cmd.Connection = conn;
                cmd.CommandText = "select ItemName, ItemPrepTime, ItemPrice from Restaurant where ItemId=" + ddl_item.SelectedItem.Value;
                IDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    var menuList = new Item();
                    //menuList.ItemId = Convert.ToInt32(dr["itemId"]);
                    menuList.ItemId = ddl_item.SelectedIndex;
                    menuList.ItemName = dr["ItemName"].ToString();
                    menuList.ItemPrepTime = Convert.ToInt32(dr["ItemPrepTime"].ToString());
                    menuList.ItemPrice = Convert.ToSingle(dr["ItemPrice"].ToString()) * (Convert.ToInt32(txt_quant.Text));
                   // menuList.

                    cart.Add(menuList);
                }
                Session["cart"] = cart;

                conn.Close();
                GridView_Order.DataSource = cart;
                GridView_Order.DataBind();
                //var item = MenuService.itemList.ToList().Find(x => x.ItemId == int.Parse(ddl_item.Text));
                //if (item != null)
                //{
                //    var maxId = cart.Max(x => x.ItemId);
                //    cart.Add(new Item { ItemId = maxId + 1, ItemName = item.ItemName, ItemPrepTime = item.ItemPrepTime, ItemPrice = item.ItemPrice * (Convert.ToInt32(txt_quant.Text)) });
                //    Session["cart"] = cart;

                //}


            }

           

            //GridView_Order.DataSource = Session["cart"];
            //GridView_Order.DataBind();
            //loaditem();
        }
    }





    protected void GridView_Order_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        List<Item> list = (List<Item>)Session["cart"];
        int index = e.RowIndex;
        var itemId = int.Parse(GridView_Order.Rows[index].Cells[1].Text);
        //Response.Write(itemId);
        if (Session["cart"] != null)
        {
            var item = list.Find(x => x.ItemId == itemId);
            list.Remove(item);
            Session["cart"] = list;
            //loaditem(); 
            GridView_Order.DataSource = Session["cart"];
            GridView_Order.DataBind();
        }
    }

    protected void GridView_Order_RowEditing(object sender, GridViewEditEventArgs e)
    {
        int index = e.NewEditIndex;
        var itemId = GridView_Order.Rows[index].Cells[1];
        Response.Write(itemId);
    }

    protected void btn_bill_Click(object sender, EventArgs e)
    {

        GridView_Order.Enabled = false;
        lbl_bill.Visible = true;
        lbl_amount.Visible = true;
        // gv_bill = true;

        for (int i = 0; i < GridView_Order.Rows.Count; i++)
        {

            sum += Convert.ToInt32(GridView_Order.Rows[i].Cells[4].Text);
            OffersBill();

        }
        lbl_bill.Text = "Rs. " + sum.ToString();

        DateTime orderDate = DateTime.Now.Date;

        gv_bill.DataSource = Session["cart"];
        gv_bill.DataBind();

    }

    public void OffersBill()
    {

        Random r = new Random();
        Response.Write(Session["category"]);

        if (Session["category"].Equals("Corporate Customer"))
        {
            if (sum > 1000)
            {
                int voucher = r.Next(50, 1000);
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('Congrats You have won a meal voucher of Rs." + voucher + "');", true);
                // Response.Write("<script> alert('Congrats You have won a meal voucher of Rs.' ) </script>"+voucher);
                // Response.Write("<alert>'Congratss!!!'</alert>");

            }

        }
        else if(Session["category"].Equals("Regular Customer"))
        {
            //DateTime dt = DateTime.Now;

            DayOfWeek today = DateTime.Today.DayOfWeek;
            //var myitem = "Pizza";
            if((today==DayOfWeek.Saturday) || (today==DayOfWeek.Sunday))
            {
                if(sum>1000)
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('Congrats You have got 10% discount');", true);
                    sum -= sum * 0.10;
                    lbl_bill.Text = "Rs. " + sum.ToString();
                }
            }

            else
            {
                List<Item> list = (List<Item>)Session["cart"];
                var iId = 1;
                var item = list.Find(x => x.ItemId == iId);
                if (list.Contains(item))
                {
                     Page.ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('Congrats!! you got 1 Pizza free');", true);
                }

            }

        }

    }
}





   




