﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration : System.Web.UI.Page
{
    SqlConnection conn;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        
    }

  

    protected void btn_register_Click(object sender, EventArgs e)
    {
        using (SqlCommand cmd = new SqlCommand())
        {
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "insert into Restaurant_Registration values(@name,@mobile,@pwd,@gender,@email,@category)";
            cmd.Parameters.AddWithValue("name", txt_name.Text);
            cmd.Parameters.AddWithValue("mobile", txt_mobile.Text);
            cmd.Parameters.AddWithValue("pwd", txt_pwd.Text);
            cmd.Parameters.AddWithValue("gender", rbl_gender.SelectedValue);
            cmd.Parameters.AddWithValue("email", txt_email.Text);
            cmd.Parameters.AddWithValue("category", ddl_category.Text);

            int i=cmd.ExecuteNonQuery();
            conn.Close();
            if(i>0)
            {
                Response.Write("<script type = 'text/javascript'>alert('Registered Successfully');</script>");
               
                    Clear();
                //   loadUser();
                Response.Redirect("login.aspx");
                
            }

        }
    }

    private void Clear()
    {
        foreach (Control item in ((ContentPlaceHolder)this.Master.FindControl("ContentPlaceHolder1")).Controls)
        {
            if (item is TextBox)
            {
                var temp = item as TextBox;
                temp.Text = "";
            }

            if (item is DropDownList)
            {
                var temp = item as DropDownList;
                temp.ClearSelection();
            }
        }

    }
}