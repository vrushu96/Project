﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Session["name"] != null)
        {
            linkbtn_logout.Text = "Logout";
            
            lbl_user.Text="Welcome " + Session["name"].ToString();
            lbl_cat.Text = Session["category"].ToString();


        }

       // if(Session["category"] == )





        else
        {
            linkbtn_logout.Text = "Login";
            lbl_user.Text = "Welcome Guest User";
        }

    }



    protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
    {

    }

    protected void linkbtn_logout_Click(object sender, EventArgs e)
    {
        if(linkbtn_logout.Text=="Logout")
        {
            Session.Abandon();
        }
        Response.Redirect("Login.aspx");
    }

    protected void lbtn_cart_Click(object sender, EventArgs e)
    {

    }
}
