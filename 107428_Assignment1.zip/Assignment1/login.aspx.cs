﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Request.QueryString["error"] != null)
        {
            Response.Write("<script> alert('Please login first') </script>");
            ViewState["nextPage"] = Request.QueryString["page"].ToString();
        }
    }


    protected void btn_login_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))
        using (SqlCommand cmd = new SqlCommand())
        {
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = "select name, password, category from Restaurant_Registration where name=@name and password=@password and category=@category";
            cmd.Parameters.AddWithValue("name", txt_uname.Text);
            cmd.Parameters.AddWithValue("password", txt_upwd.Text);
            cmd.Parameters.AddWithValue("category", ddl_cat.SelectedValue);

            
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.Read())
            {
                Session["name"] = dr["name"].ToString();
                Session["password"] = dr["password"].ToString();
                Session["category"] = dr["category"].ToString();

                


                if(ViewState["page"]==null)
                {
                    //Response.Write("<script> alert('Login Successful !!!') </script>");
                    Response.Redirect("index.aspx");
                }

                else
                {
                    //Response.Write("<script> alert('Username/Password  not matched !!!') </script>");
                    lbl_incorrect.Text = "User name / password not matched !!";

                }
                dr.Close();
                conn.Close();
            }
        }
    }

    
}